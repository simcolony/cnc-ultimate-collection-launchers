===========================================================

COMMAND & CONQUER ULTIMATE COLLECTION LAUNCHERS

Version: 1.19
Author: Bibber
eMail: info@bibber.eu
Homepage: http://bibber.eu

-----------------------------------------------------------

DESCRIPTION:
  These are fixed launchers for the Command & Conquer Ultimate Collection which fix some registry entries and let command-line parameters pass through.
  Use at your own risk.

REQUIREMENTS:
  Command & Conquer Ultimate Collection

INSTALLATION:
  Run the setup.

COMMAND-LINE PARAMETERS
  -game gen|genep1|cnc3|cnc3ep1|ra2|ra2ep1|ra3|ra3ep1
      Launches the game directly instead of popping up the window for choosing.
          cnc3		= C&C 3 Tiberium Wars
          cnc3ep1	= C&C 3 Kane's Wrath
          gen		= C&C Generals
          genep1	= C&C Generals Zero Hour
          ra2		= C&C Red Alert 2
          ra2ep1	= C&C Red Alert 2 Yuri's Revenge
          ra3		= C&C Red Alert 3
          ra3ep1	= C&C Red Alert 3 Uprising

UNINSTALL:
  In Origin right-click the games and repair them.

===========================================================