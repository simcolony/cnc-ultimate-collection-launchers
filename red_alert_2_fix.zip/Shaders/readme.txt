This is a package of pixel shaders intended for old school emulators. 
Copyrights are held by the respective authors.

https://github.com/libretro/glsl-shaders
